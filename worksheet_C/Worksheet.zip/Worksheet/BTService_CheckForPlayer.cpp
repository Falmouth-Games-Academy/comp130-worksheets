// Fill out your copyright notice in the Description page of Project Settings.

#include "Worksheet.h"
#include "Bot_Controller.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/Blackboard/BlackboardKeyAllTypes.h"
#include "Bot.h"
#include "Bot_Controller.h"
#include "BTService_CheckForPlayer.h"
#include "WorksheetCharacter.h"






UBTService_CheckForPlayer::UBTService_CheckForPlayer()
{
	bCreateNodeInstance = true;
}
void UBTService_CheckForPlayer::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) 
{
	ABot_Controller *EnemyPC = Cast<ABot_Controller>(OwnerComp.GetAIOwner());

	AWorksheetCharacter *Enemy = Cast<AWorksheetCharacter>(GetWorld()->GetFirstPlayerController()->GetPawn());

	if (Enemy) 
	{
		OwnerComp.GetBlackboardComponent()->SetValue<UBlackboardKeyType_Object>(EnemyPC->EnemyKeyID, Enemy);
	}
}